package builder.entities.npc;

import builder.GameState;
import builder.entities.npc.enemies.Enemy;
import builder.ui.SpriteGallery;

import engine.EngineState;
import engine.art.sprites.SpriteGroup;
import engine.timing.RepeatingTimer;

import java.util.ArrayList;

public class BeeHive extends Npc {

    public static final int DETECTION_DISTANCE = 350;
    public static final int TIMER_DURATION = 100;
    public static final int FOOD_COST = 2;
    public static final int COIN_COST = 2;

    private static final SpriteGroup ART = SpriteGallery.hive;

    private boolean loaded = true;
    private final RepeatingTimer reloadTimer = new RepeatingTimer(TIMER_DURATION);

    public BeeHive(int x, int y) {
        super(x, y);
        setSprite(ART.getSprite("default"));
        setSpeed(0);
    }

    @Override
    public void tick(EngineState state, GameState game) {
        super.tick(state);
        updateReloadStatus();
    }

    private void updateReloadStatus() {
        if (!loaded) {
            reloadTimer.tick();
            if (reloadTimer.isFinished()) {
                loaded = true;
            }
        }
    }

    @Override
    public void interact(EngineState state, GameState game) {
        super.interact(state, game);
        attemptBeeSpawn(game);
    }

    private void attemptBeeSpawn(GameState game) {
        GuardBee bee = createBeeIfEnemyInRange(game.getEnemies().Birds);
        if (bee != null) {
            game.getNpcs().npcs.add(bee);
            loaded = false;
        }
    }

    private GuardBee createBeeIfEnemyInRange(ArrayList<Enemy> enemies) {
        if (!loaded) {
            return null;
        }

        for (Enemy enemy : enemies) {
            if (isEnemyInRange(enemy)) {
                return new GuardBee(getX(), getY(), enemy);
            }
        }
        return null;
    }

    private boolean isEnemyInRange(Enemy enemy) {
        return distanceFrom(enemy) < DETECTION_DISTANCE;
    }
}