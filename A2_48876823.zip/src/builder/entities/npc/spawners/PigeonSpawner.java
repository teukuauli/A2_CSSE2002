package builder.entities.npc.spawners;

import builder.GameState;
import builder.entities.resources.Cabbage;
import builder.entities.tiles.Tile;

import engine.EngineState;
import engine.game.HasPosition;
import engine.timing.RepeatingTimer;
import engine.timing.TickTimer;

import java.util.List;

public class PigeonSpawner implements Spawner {

    private static final int DEFAULT_SPAWN_INTERVAL = 100;

    private int x;
    private int y;
    private final RepeatingTimer timer;

    public PigeonSpawner(int x, int y) {
        this(x, y, DEFAULT_SPAWN_INTERVAL);
    }

    public PigeonSpawner(int x, int y, int duration) {
        this.x = x;
        this.y = y;
        this.timer = new RepeatingTimer(duration);
    }

    @Override
    public TickTimer getTimer() {
        return timer;
    }

    @Override
    public void tick(EngineState state, GameState game) {
        timer.tick();

        if (timer.isFinished()) {
            attemptPigeonSpawn(game);
        }
    }

    private void attemptPigeonSpawn(GameState game) {
        List<Tile> cabbageTiles = findCabbageTiles(game);

        if (!cabbageTiles.isEmpty()) {
            Tile closestCabbage = findClosestCabbage(cabbageTiles);
            spawnPigeon(game, closestCabbage);
        }
    }

    private List<Tile> findCabbageTiles(GameState game) {
        return game.getWorld().tileSelector(tile ->
                tile.getStackedEntities().stream()
                        .anyMatch(entity -> entity instanceof Cabbage)
        );
    }

    private Tile findClosestCabbage(List<Tile> cabbageTiles) {
        Tile closest = cabbageTiles.get(0);
        int minDistance = distanceFrom(closest);

        for (Tile tile : cabbageTiles) {
            int distance = distanceFrom(tile);
            if (distance < minDistance) {
                minDistance = distance;
                closest = tile;
            }
        }
        return closest;
    }

    private void spawnPigeon(GameState game, Tile target) {
        game.getEnemies().spawnX = getX();
        game.getEnemies().spawnY = getY();
        game.getEnemies().Birds.add(game.getEnemies().mkP(target));
    }

    private int distanceFrom(HasPosition position) {
        int deltaX = position.getX() - getX();
        int deltaY = position.getY() - getY();
        return (int) Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    }

    @Override
    public int getX() {
        return x;
    }

    @Override
    public void setX(int x) {
        this.x = x;
    }

    @Override
    public int getY() {
        return y;
    }

    @Override
    public void setY(int y) {
        this.y = y;
    }
}